# Interval Timer

[Click Here](https://greggman.github.io/interval-timer/)

A simple interval timer. Settings are saved in the URL so set them to whatever
you want and then make a bookmark.

## TO DO

* Localize?





